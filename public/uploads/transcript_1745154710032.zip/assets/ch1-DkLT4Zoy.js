const s="/assets/ch1-ClLpcDVu.jpg";export{s as a};
