const s="/assets/4-CidOHcBZ.jpg",a="/assets/about-DQniisaG.jpg";export{a,s as c};
