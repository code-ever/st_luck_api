const s="/assets/other-CaqX1PMD.jpg";export{s as m};
